## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- eval = FALSE------------------------------------------------------------
#  install.packages('ggcognigen_1.1.0.9000.tar.gz', type = 'source')

## ----setup--------------------------------------------------------------------
library(ggcognigen)

## ---- echo = FALSE------------------------------------------------------------
set_default_style(style = 'ggplot2')

## ---- fig.dim = c(6, 3.5)-----------------------------------------------------
library(ggplot2)
ggplot(data = diamonds) +
  aes(x = carat, y = price) + 
  geom_point() +
  facet_wrap(vars(clarity))

## ---- fig.dim = c(8, 3.5)-----------------------------------------------------
ggplot2::reset_theme_settings()
ggpubr::ggarrange(
  ggplot(data = xydata) +
    aes(x = TIME, y = CONCENTRATION) + 
    geom_point() +
    ggtitle('Default ggplot2 theme'),
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS) +
    geom_boxplot() +
    theme_cognigen() +
    ggtitle('Cognigen theme'),
  nrow = 1,
  ncol = 2
)

## ---- fig.dim = c(6, 3.5)-----------------------------------------------------
ggplot(data = diamonds) +
  aes(x = carat, y = price) + 
  geom_point() +
  facet_wrap(vars(clarity)) +
  theme_cognigen_grid()

## -----------------------------------------------------------------------------
ggplot2::theme_set(theme_cognigen())

## ---- echo = FALSE------------------------------------------------------------
#xydata <- subset(xydata, REP == 1)

## ---- echo = FALSE------------------------------------------------------------
set_default_style()

## ---- fig.dim = c(8, 3.5)-----------------------------------------------------
ggpubr::ggarrange(
  ggplot(data = xydata) +
    aes(x = TIME, y = CONCENTRATION) + 
    geom_point(),
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS) +
    geom_boxplot(),
  nrow = 1,
  ncol = 2
)


## ---- eval = FALSE------------------------------------------------------------
#  # Revert to ggplot2 styling
#  set_default_style(style = 'ggplot2')

## ---- eval = FALSE------------------------------------------------------------
#  set_default_style(style = read_style('/path/to/my/style.json'))

## ---- fig.dim = c(8, 6.5)-----------------------------------------------------
ggpubr::ggarrange(
  ggplot(data = xydata) +
    aes(x = TIME, y = CONCENTRATION, colour = GROUP, shape = GROUP) +
    geom_point() +
    geom_line() +
    scale_discrete_cognigen(),
  ggplot(data = diamonds) +
    aes(x = carat, y = price, colour = clarity, shape = clarity, fill = clarity) + 
    geom_smooth() +
    scale_discrete_cognigen(),
  ggplot(data = bardata) +
    aes(x = STUDY, y = COUNT, fill = GROUP) +
    geom_bar(stat = 'identity', position = 'stack', alpha = 1) +
    scale_discrete_cognigen(geom = 'bar'),
  nrow = 2,
  ncol = 2
)

## ---- fig.dim = c(8, 7)-------------------------------------------------------
ggpubr::ggarrange(
  ggplot(diamonds) +
    aes(x = carat, y = depth) +
    geom_point(aes(colour = price), pch = 19) +
    scale_continuous_cognigen() + 
    ggtitle('continuous color'),
  ggplot(faithfuld, aes(waiting, eruptions)) +
    geom_raster(aes(fill = density)) +
    scale_continuous_cognigen() + 
    ggtitle('continuous fill'),
  nrow = 2,
  ncol = 1
)

## -----------------------------------------------------------------------------
str(cognigen_style())

## -----------------------------------------------------------------------------
style <- cognigen_style()
style$scatter$color$lty
style$bar$grayscale$col

## ---- fig.dim = c(8, 6.5)-----------------------------------------------------
ggpubr::ggarrange(
  ggplot(data = xydata) +
    aes(x = TIME, y = CONCENTRATION, colour = GROUP, shape = GROUP) +
    geom_point() +
    geom_line() +
    scale_discrete_cognigen(style = cognigen_purple_style()),
  ggplot(data = diamonds) +
    aes(x = carat, y = price, colour = clarity, shape = clarity, fill = clarity) + 
    geom_smooth() +
    scale_discrete_cognigen(style = cognigen_purple_style()),
  ggplot(data = bardata) +
    aes(x = STUDY, y = COUNT, fill = GROUP) +
    geom_bar(stat = 'identity', position = 'stack', alpha = 1) +
    scale_discrete_cognigen(style = cognigen_purple_style(), geom = 'bar'),
  nrow = 2,
  ncol = 2
)

## ---- fig.dim = c(8, 6.5)-----------------------------------------------------
ggpubr::ggarrange(
  ggplot(data = xydata) +
    aes(x = TIME, y = CONCENTRATION, colour = GROUP, shape = GROUP) +
    geom_point() +
    geom_line() +
    scale_discrete_cognigen(style = cognigen_purple_style(gray.first = TRUE)),
  ggplot(data = diamonds) +
    aes(x = carat, y = price, colour = clarity, shape = clarity, fill = clarity) + 
    geom_smooth() +
    scale_discrete_cognigen(style = cognigen_purple_style(n = 8)),
  ggplot(data = bardata) +
    aes(x = STUDY, y = COUNT, fill = GROUP) +
    geom_bar(stat = 'identity', position = 'stack', alpha = 1) +
    scale_discrete_cognigen(style = cognigen_purple_style(gray.first = TRUE), geom = 'bar'),
  nrow = 2,
  ncol = 2
)

## ----eval=FALSE---------------------------------------------------------------
#  ggplot(data = xydata) +
#      aes(x = TIME, y = CONCENTRATION, colour = GROUP, shape = GROUP) +
#      geom_point() +
#      geom_line() +
#      scale_discrete_cognigen()

## ---- fig.dim = c(8, 3.5)-----------------------------------------------------
ggpubr::ggarrange(
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS) +
    geom_boxplot2(coef = 1.5, outlier.position = 'identity') +
    ggtitle('coef = 1.5'),
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS) +
    geom_boxplot2(coef = 90, outlier.position = 'identity') +
    ggtitle('coef = 90'),
  nrow = 1,
  ncol = 2
)

## ---- fig.dim = c(4, 3.5)-----------------------------------------------------
ggplot(data = boxdata) +
  aes(x = GROUP, y = CONTINUOUS) +
  geom_boxplot2(whisker.cap = TRUE, outlier.position = 'identity')


## ---- fig.dim = c(8, 3.5)-----------------------------------------------------
ggpubr::ggarrange(
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS) +
    geom_boxplot2(outlier.position = NULL) +
    ggtitle('NULL'),
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS) +
    geom_boxplot2(outlier.position = 'identity') +
    ggtitle('\'identity\''),
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS) +
    geom_boxplot2() +
    ggtitle('default or \'jitter\''),
  nrow = 1,
  ncol = 3
)

## ---- fig.dim = c(8, 7)-------------------------------------------------------
ggpubr::ggarrange(
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS, color = CATEGORICAL, shape = CATEGORICAL, fill = CATEGORICAL) +
    geom_boxplot(
      notch = TRUE,
      position = position_dodge(width = 0.9)
    ) +
    ggtitle('geom_boxplot()') +
    scale_discrete_cognigen(geom = 'boxplot'),
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS, color = CATEGORICAL, shape = CATEGORICAL, fill = CATEGORICAL) +
    geom_boxplot2(
      notch = TRUE,
      position = position_dodge(width = 0.9)
    ) +
    ggtitle('geom_boxplot2()') +
    scale_discrete_cognigen(geom = 'boxplot'),
  nrow = 2,
  ncol = 1
)

## ---- fig.dim = c(8, 3.5)-----------------------------------------------------
ggplot(data = boxdata) +
  aes(x = GROUP, y = CONTINUOUS, color = CATEGORICAL, shape = CATEGORICAL, fill = CATEGORICAL) +
  geom_boxplot2(
    notch = TRUE,
    position = position_dodge(width = 0.9)
  ) +
  geom_boxcount(
    position = position_dodge(width = 0.9)
  ) + 
  scale_discrete_cognigen(geom = 'boxplot')

## ---- fig.dim = c(6, 3.5)-----------------------------------------------------
ggplot(mpg, aes(class, hwy)) +
  geom_boxplot2() +
  geom_boxcount() +
  scale_y_continuous(trans = 'log10')

## ---- fig.dim = c(8, 3.5)-----------------------------------------------------
ggplot(data = bardata) +
  aes(x = STUDY, y = COUNT, fill = GROUP) +
  geom_bar(stat = 'identity') +
  geom_barcount() +
  scale_discrete_cognigen(geom = 'bar')

## ---- fig.dim = c(8, 3.5)-----------------------------------------------------
ggplot(data = bardata) +
  aes(x = STUDY, y = COUNT, fill = GROUP) +
  geom_bar(stat = 'identity') +
  geom_barcount(overall.stack = FALSE) +
  scale_discrete_cognigen(geom = 'bar')

## ---- fig.dim = c(8, 7)-------------------------------------------------------
ggpubr::ggarrange(
  ggplot(data = bardata) +
    aes(x = STUDY, y = COUNT, fill = GROUP) +
    geom_bar(stat = 'identity', position = 'dodge') +
    geom_barcount(position = position_dodge(width = 0.9)) +
    ylab('Count') +
    scale_discrete_cognigen(geom = 'bar') +
    ggtitle('dodge'),
  ggpubr::ggarrange(
    ggplot(data = bardata) +
      aes(x = STUDY, y = COUNT, fill = GROUP) +
      geom_bar(stat = 'identity', position = 'fill') +
      geom_barcount(position = position_fill()) +
      scale_discrete_cognigen(geom = 'bar') +
      ylab('Normalized Count') +
      theme(legend.position = 'none') +
      ggtitle('fill'),
    ggplot(data = bardata) +
      aes(x = STUDY, y = COUNT, fill = GROUP) +
      geom_bar(stat = 'identity', position = 'fillpercent') +
      geom_barcount(position = position_fillpercent()) +
      scale_discrete_cognigen(geom = 'bar') +
      ylab('Normalized Count (%)') +
      theme(legend.position = 'none') +
      ggtitle('fillpercent'),
    ncol = 2,
    nrow = 1
  ),
  nrow = 2,
  ncol = 1
)


## ---- fig.dim = c(6, 7)-------------------------------------------------------
ggpubr::ggarrange(
  ggplot(data = bardata) +
    aes(x = STUDY, y = COUNT, fill = GROUP) +
    geom_bar(stat = 'identity', position = 'fillpercent') +
    geom_barcount(position = position_fillpercent(),
                  digits = 4) +
    scale_discrete_cognigen(geom = 'bar') +
    ylab('Normalized Count (%)') +
    theme(legend.position = 'none') +
    ggtitle('digits = 4'),
  ggplot(data = bardata) +
    aes(x = STUDY, y = COUNT, fill = GROUP) +
    geom_bar(stat = 'identity', position = 'fillpercent') +
    geom_barcount(position = position_fillpercent(),
                  digits = 0) +
    scale_discrete_cognigen(geom = 'bar') +
    ylab('Normalized Count (%)') +
    theme(legend.position = 'none') +
    ggtitle('digits = 0 to display as an integer'),
  nrow = 2,
  ncol = 1
  )

## ---- fig.dim = c(6, 3.5)-----------------------------------------------------
ggplot(data = histdata) +
  aes(x = RANDOM) +
  geom_histogram(bins = 15) +
  geom_histcount(bins = 15) +
  scale_discrete_cognigen(geom = 'histogram')

## ---- fig.dim = c(6, 7)-------------------------------------------------------
ggpubr::ggarrange(
  ggplot(data = histdata) +
    aes(x = RANDOM, fill = GROUP) +
    geom_histogram(aes(y = ..density..), stat = 'bin2', bins = 15) +
    geom_histcount(aes(y = ..density.., label = ..density_label..), bins = 15)  +
    scale_discrete_cognigen(geom = 'histogram') +
    ylab('Density'),
  ggplot(data = histdata) +
    aes(x = RANDOM, fill = GROUP) +
    geom_histogram(aes(y = ..percent..), stat = 'bin2', bins = 15) +
    geom_histcount(aes(y = ..percent.., label = ..percent_label..), bins = 15) +
    ylab('Percent (%)') +
    scale_discrete_cognigen(geom = 'histogram'),
  nrow = 2,
  ncol = 1
)

## ---- fig.dim = c(6, 3.5)-----------------------------------------------------
ggplot(data = boxdata) +
  aes(x = CATEGORICAL) +
  geom_histogram(stat = 'count') +
  geom_barcount()

## -----------------------------------------------------------------------------
set.seed(123)
random_data <- data.frame(x = runif(1000, 0, 10000), y = rlnorm(1000, 0, 3))

ggplot(random_data, aes(x = x, y = y)) +
  geom_point() +
  theme_cognigen_grid(minor.x = TRUE, minor.y = TRUE) +
  scale_x_continuous(labels = format_continuous_cognigen) + 
  scale_y_continuous(
    trans = 'log10', 
    breaks = major_breaks_log,
    minor_breaks = minor_breaks_log,
    labels = format_continuous_cognigen
  )

