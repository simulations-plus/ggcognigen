# Suppress R CMD check note by confirming one function is imported from each package
#' @importFrom glue glue
#' @importFrom grid grobTree
#' @importFrom quantreg rq
#' @importFrom utils page
#' @importFrom grDevices col2rgb
NULL
