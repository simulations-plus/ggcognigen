## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  error = FALSE
)

## ----echo=FALSE, message=FALSE------------------------------------------------
library(tidyverse)
library(ggcognigen)

## ----class.source = 'fold-show'-----------------------------------------------
glimpse(expo)

## ----class.source = 'fold-show'-----------------------------------------------
expo25 <- expo %>% filter(DOSE == '25 mg')
gmr25_aucss <- make_gmr_data(
  data = expo25,
  x_var = 'AUCSS',
  id_var = 'ID',
  covariates = c('AGE', 'WTKG', 'BMI', 'SEXF', 'RFCAT', 'CPCAT', 'HFM')
)

## ----class.source = 'fold-show'-----------------------------------------------
glimpse(gmr25_aucss)

## ----class.source = 'fold-show', collapse=TRUE--------------------------------
gmr25_all <- make_gmr_data(
  data = expo25,
  x_var = c('AUCSS', 'CMAXSS', 'CMINSS'),
  id_var = 'ID',
  covariates = c('AGE', 'WTKG', 'BMI', 'SEXF', 'RFCAT', 'CPCAT', 'HFM'),
  silent = TRUE
)
glimpse(gmr25_all)
unique(gmr25_all$x_var)

## ----class.source = 'fold-show'-----------------------------------------------
gmr_all <- make_gmr_data(
  data = expo,
  x_var = c('AUCSS', 'CMAXSS', 'CMINSS'),
  id_var = 'ID',
  by = 'DOSE',
  covariates = c('AGE', 'WTKG', 'BMI', 'SEXF', 'RFCAT', 'CPCAT', 'HFM'),
  silent = TRUE
)
glimpse(gmr_all)
unique(gmr_all[, c('x_var', 'by')])

## ----class.source = 'fold-show'-----------------------------------------------
gmr_all <- make_gmr_data(
  data = expo,
  x_var = c('AUCSS', 'CMAXSS', 'CMINSS'),
  id_var = 'ID',
  by = 'DOSE',
  covariates = c('AGE', 'WTKG', 'BMI', 'SEXF', 'RFCAT', 'CPCAT', 'HFM'),
  ref_levels = c(2, 3, 2, 1, 1, 1, 1),
  labels = c(
    expression('Age'~'(y)'),
    expression('Body'~'Weight'~'(kg)'),
    expression('Body'~'Mass'~'Index'~'(kg/'*m^2*')'),
    expression('Sex'),
    expression('Renal'~'Function'),
    expression('Hepatic'~'Function'~'(Child-Pugh)'),
    expression('Meal'~'Status')
  ),
  digits = 4,
  ci = 0.95,
  silent = TRUE
)
glimpse(gmr_all)
unique(gmr_all[, c('x_var', 'by')])

## ----fig.height=7, fig.width=7, class.source = 'fold-hide'--------------------
gmr25_aucss <- make_gmr_data(
  data = expo25,
  x_var = 'AUCSS',
  id_var = 'ID',
  covariates = c('AGE', 'WTKG', 'BMI', 'SEXF', 'RFCAT', 'CPCAT', 'HFM'),
  ref_levels = c(2, 3, 2, 1, 1, 1, 1),
  labels = c(
    expression('Age'~'(y)'),
    expression('Body'~'Weight'~'(kg)'),
    expression('Body'~'Mass'~'Index'~'(kg/'*m^2*')'),
    expression('Sex'),
    expression('Renal'~'Function'),
    expression('Hepatic'~'Function'~'(Child-Pugh)'),
    expression('Meal'~'Status')
  ),
  silent = TRUE
)
p1 <- make_forestplot(
  data = gmr25_aucss,
  y = 'value', x = 'gmr', xmin = 'gmr_lo', xmax = 'gmr_hi',
  label = 'gmr_n_label',
  facet = 'y_label',
  vline_primary = 1,
  vline_secondary = c(0.8, 1.25),
  xlb = 'Geometric Mean Ratio [90% confidence interval]',
  title = expression(AUC[ss*','~0 ~'-'~24~h]~'(nmol' %*% 'h/L)'),
  fatten = 2,
  small_font = TRUE
)
p1

## ----fig.height=7, fig.width=7, class.source = 'fold-hide'--------------------
make_forestplot(
  data = gmr25_aucss,
  y = 'value', x = 'gmr', xmin = 'gmr_lo', xmax = 'gmr_hi',
  label = NULL,
  facet = 'y_label',
  vline_primary = 1,
  vline_secondary = c(0.8, 1.25),
  xlb = 'Geometric Mean Ratio [90% confidence interval]',
  title = expression(AUC[ss*','~0 ~'-'~24~h]~'(nmol' %*% 'h/L)'),
  fatten = 2,
  small_font = TRUE
)

## ----fig.height=7, fig.width=7, class.source = 'fold-hide'--------------------
gmr25_aucss <- expo25 %>%
  make_gmr_data(
    x_var = AUCSS,
    id_var = ID,
    covariates = c(AGE, WTKG, BMI, SEXF, RFCAT, CPCAT, HFM),
    ref_levels = c(2, 3, 2, 1, 1, 1, 1),
    labels = c(
      expression('Age'~'(y)'),
      expression('Body'~'Weight'~'(kg)'),
      expression('Body'~'Mass'~'Index'~'(kg/'*m^2*')'),
      expression('Sex'),
      expression('Renal'~'Function'),
      expression('Hepatic'~'Function'~'(Child-Pugh)'),
      expression('Meal'~'Status')
    ),
    silent = TRUE
  )
p1 <- make_forestplot(
  data = gmr25_aucss,
  y = value, x = gmr, xmin = gmr_lo, xmax = gmr_hi,
  label = NULL,
  facet = y_label,
  vline_primary = 1,
  vline_secondary = c(0.8, 1.25),
  xlb = 'Geometric Mean Ratio [90% confidence interval]',
  title = expression(AUC[ss*','~0 ~'-'~24~h]~'(nmol' %*% 'h/L)'),
  fatten = 2,
  small_font = TRUE
)
p1

## ----fig.height=7, fig.width=7, class.source = 'fold-hide'--------------------

make_forestplot(
  data = gmr25_aucss,
  y = 'value', x = 'gmr', xmin = 'gmr_lo', xmax = 'gmr_hi',
  label = 'gmr_n_label',
  facet = 'y_label',
  vline_primary = 1,
  vline_secondary = c(0.8, 1.25),
  xlb = 'Geometric Mean Ratio [90% confidence interval]',
  title = expression(AUC[ss*','~0 ~'-'~24~h]~'(nmol' %*% 'h/L)'),
  n_label = 'patient',
  fatten = 2,
  small_font = TRUE
)

## ----fig.height=7, fig.width=7, class.source = 'fold-hide'--------------------
p1 + scale_x_continuous(
  trans = 'log10',
  breaks = c(0.6, 0.7, 0.8, 0.9, 1, 1.1, 1.2, 1.3, 1.4),
  labels = format_continuous_cognigen
)

## ----fig.height=7, fig.width=7------------------------------------------------
make_forestplot(
  data = gmr25_aucss,
  y = 'value', x = 'gmr', xmin = 'gmr_lo', xmax = 'gmr_hi',
  label = 'gmr_n_label',
  facet = 'y_label',
  reference = 'reference',
  vline_primary = 1,
  vline_secondary = c(0.8, 1.25),
  xlb = 'Geometric Mean Ratio [90% confidence interval]',
  title = expression(AUC[ss*','~0 ~'-'~24~h]~'(nmol' %*% 'h/L)'),
  fatten = 2,
  small_font = TRUE
)

## ----fig.height=7, fig.width=7, class.source = 'fold-hide'--------------------
gmr25_aucss <- gmr25_aucss %>% 
  mutate(
    value_mod = factor(value, levels(value)[c(2, 1, 3, 5, 6, 4, 7, 8, 10, 9, 11:20)])
  )
levels(gmr25_aucss$value)
levels(gmr25_aucss$value_mod)

make_forestplot(
  data = gmr25_aucss,
  y = 'value_mod', x = 'gmr', xmin = 'gmr_lo', xmax = 'gmr_hi',
  label = 'gmr_n_label',
  facet = 'y_label',
  reference = 'reference',
  vline_primary = 1,
  vline_secondary = c(0.8, 1.25),
  xlb = 'Geometric Mean Ratio [90% confidence interval]',
  title = expression(AUC[ss*','~0 ~'-'~24~h]~'(nmol' %*% 'h/L)'),
  fatten = 2,
  small_font = TRUE
)

## ----fig.height=7, fig.width=7------------------------------------------------
gmr25_aucss <- gmr25_aucss %>% 
  mutate(
    group = factor(
      ifelse(
        is.na(gmr),
        1,
        ifelse(
          gmr >= 0.8 & gmr <= 1.25,
          ifelse( gmr_lo < 0.8 | gmr_hi > 1.25, 2, 1),
          ifelse( gmr_hi < 0.8 | gmr_lo > 1.25, 4, 3)
        )
      ),
      labels = c('CI inside limits', 'CI partially outside limits', 'GMR outside limits', 'CI fully ouside limits')
    )
  )

make_forestplot(
  data = gmr25_aucss,
  y = 'value_mod', x = 'gmr', xmin = 'gmr_lo', xmax = 'gmr_hi',
  label = 'gmr_n_label',
  color = 'group',
  facet = 'y_label',
  reference = 'reference',
  vline_primary = 1,
  vline_secondary = c(0.8, 1.25),
  xlb = 'Geometric Mean Ratio [90% confidence interval]',
  title = expression(AUC[ss*','~0 ~'-'~24~h]~'(nmol' %*% 'h/L)'),
  fatten = 2,
  small_font = TRUE
) + 
  scale_color_manual(values = c('#008000', '#0000FF', '#FFA000', '#FF0000')) +
  labs(color = '')  # to remove the legend title

## ----fig.height=10, fig.width=7, class.source = 'fold-hide'-------------------
gmr_all <- make_gmr_data(
  data = expo,
  x_var = c('AUCSS', 'CMAXSS', 'CMINSS'),
  id_var = 'ID',
  by = 'DOSE',
  covariates = c('AGE', 'WTKG', 'BMI', 'SEXF', 'RFCAT', 'CPCAT', 'HFM'),
  ref_levels = c(2, 3, 2, 1, 1, 1, 1),
  labels = c(
    expression('Age'~'(y)'),
    expression('Body'~'Weight'~'(kg)'),
    expression('Body'~'Mass'~'Index'~'(kg/'*m^2*')'),
    expression('Sex'),
    expression('Renal'~'Function'),
    expression('Hepatic'~'Function'~'(Child-Pugh)'),
    expression('Meal'~'Status')
  ),
  silent = TRUE
)
p2 <- make_forestplot(
  data = subset(gmr_all, x_var == 'AUCSS'),
  y = 'value', x = 'gmr', xmin = 'gmr_lo', xmax = 'gmr_hi',
  label = 'gmr_n_label',
  color = 'by',
  facet = 'y_label',
  vline_primary = 1,
  vline_secondary = c(0.8, 1.25),
  xlb = 'Geometric Mean Ratio [90% confidence interval]',
  title = expression(AUC[ss*','~0 ~'-'~24~h]~'(nmol' %*% 'h/L)'),
  fatten = 2,
  small_font = TRUE
) +
  scale_discrete_cognigen() +
  labs(color = '')  # to remove the legend title
p2

## ----fig.height=10, fig.width=7, class.source = 'fold-hide'-------------------
logscale <- scale_x_continuous(
  trans = 'log10',
  breaks = c(0.6, 0.7, 0.8, 0.9, 1, 1.1, 1.2, 1.3, 1.4),
)
p2 +
  ggh4x::facetted_pos_scales(
    x = list(
      # one element per panel
      logscale,
      logscale,
      logscale,
      logscale,
      logscale,
      logscale,
      logscale
    )
  )

## ----fig.height=7, fig.width=7, class.source = 'fold-hide'--------------------
gmr25_all <- make_gmr_data(
  data = expo25,
  x_var = c('AUCSS', 'CMAXSS', 'CMINSS'),
  id_var = 'ID',
  covariates = c('AGE', 'WTKG', 'HFM'),
  ref_levels = c(2, 3, 1),
  labels = c(
    expression('Age'~'(y)'),
    expression('Body'~'Weight'~'(kg)'),
    expression('Meal'~'Status')
  ),
  silent = TRUE
)
p1_1 <- make_forestplot(
  data = subset(gmr25_all, x_var == 'CMINSS'),
  y = 'value', x = 'gmr', xmin = 'gmr_lo', xmax = 'gmr_hi',
  label = 'gmr_n_label',
  facet = 'y_label',
  vline_primary = 1,
  vline_secondary = c(0.8, 1.25),
  xlb = NULL,
  ylb = expression(C[ss*','*trough]~'(nmol/L)'),
  fatten = 2,
  small_font = TRUE
) +
  ggplot2::xlim( c(0.5, 1.3) ) +
  ggplot2::labs( caption = NULL )

p1_2 <- make_forestplot(
  data = subset(gmr25_all, x_var == 'AUCSS'),
  y = 'value', x = 'gmr', xmin = 'gmr_lo', xmax = 'gmr_hi',
  label = 'gmr_n_label',
  facet = 'y_label',
  vline_primary = 1,
  vline_secondary = c(0.8, 1.25),
  xlb = 'Geometric Mean Ratio [90% confidence interval]',
  ylb = expression(AUC[0 ~'-'~12~h]~'(nmol' %*% 'h/L)'),
  fatten = 2,
  small_font = TRUE
) +
  ggplot2::xlim( c(0.5, 1.3) )

p2_1 <- ggplot() + theme_void()

suppressWarnings(
  ggpubr::ggarrange(
    p1_1, p2_1, p1_2,
    nrow = 2, ncol = 2,
    widths = c(0.95, 0.05),
    heights = c(0.45, 0.55)
  )
)


## ----fig.height=9, fig.width=7, class.source = 'fold-hide'--------------------
gmr_all <- make_gmr_data(
  data = expo,
  x_var = c('AUCSS', 'CMAXSS', 'CMINSS'),
  id_var = 'ID',
  covariates = c('AGE', 'WTKG', 'HFM'),
  ref_levels = c(2, 3, 1),
  by = 'DOSE',
  labels = c(
    expression('Age'~'(y)'),
    expression('Body'~'Weight'~'(kg)'),
    expression('Meal'~'Status')
  ),
  silent = TRUE
)
p1_1 <- make_forestplot(
  data = subset(gmr_all, x_var == 'CMINSS'),
  y = 'value', x = 'gmr', xmin = 'gmr_lo', xmax = 'gmr_hi',
  label = 'gmr_n_label',
  facet = 'y_label',
  color = 'by',
  reference = 'reference',
  vline_primary = 1,
  vline_secondary = c(0.8, 1.25),
  xlb = NULL,
  ylb = expression(C[ss*','*trough]~'(nmol/L)'),
  fatten = 2,
  small_font = TRUE
) +
  ggh4x::facetted_pos_scales(
    x = list(
      logscale,
      logscale,
      logscale
    )
  ) +
  ggplot2::scale_color_manual(
    values = get_style_colors(cognigen_style())[-1]
  ) + 
  ggplot2::xlim( c(0.5, 1.3) ) +
  ggplot2::labs( caption = NULL ) +
  labs(color = '')

# Extract the legend before suppressing it
plegend <- ggpubr::get_legend(p1_1)
p1_1 <- p1_1 +
  theme(legend.position = 'none')

p1_2 <- make_forestplot(
  data = subset(gmr_all, x_var == 'AUCSS'),
  y = 'value', x = 'gmr', xmin = 'gmr_lo', xmax = 'gmr_hi',
  label = 'gmr_n_label',
  facet = 'y_label',
  color = 'by',
  reference = 'reference',
  vline_primary = 1,
  vline_secondary = c(0.8, 1.25),
  xlb = 'Geometric Mean Ratio [90% confidence interval]',
  ylb = expression(AUC[0 ~'-'~12~h]~'(nmol' %*% 'h/L)'),
  fatten = 2,
  small_font = TRUE
)  +
  ggh4x::facetted_pos_scales(
    x = list(
      logscale,
      logscale,
      logscale
    )
  ) +
  ggplot2::scale_color_manual(
    values = get_style_colors(cognigen_style())[-1]
  ) +
  ggplot2::xlim( c(0.5, 1.3) ) +
  theme(legend.position = 'none')

p2_1 <- ggplot() + theme_void()

suppressWarnings(
  ggpubr::ggarrange(
  ggpubr::ggarrange(
    p1_1, p2_1, p1_2, 
    nrow = 2, ncol = 2, 
    widths = c(0.95, 0.05),
    heights = c(0.475, 0.525)
  ),
  plegend,
  nrow = 1,
  ncol = 2,
  widths = c(0.85, 0.15)
)
)


## ----eval=FALSE, class.source = 'fold-show'-----------------------------------
#  
#  # Preprocessing
#  gmr_table_data <- gmr_all[, c('x_var', 'y_label', 'value', 'by', 'n', 'gm_label','gmr_label')]
#  levels(gmr_table_data[, 'y_label']) <- expr2char(levels(gmr_table_data[, 'y_label']))
#  
#  # Request html table
#  make_gmr_table(
#    data = gmr_table_data,
#    file = 'gmtable.html',
#    format = 'html',
#    headers = c(
#      'Exposure Measure',
#      'Covariate',
#      'Group',
#      'Dose',
#      'n',
#      'Geometric Mean [90% CI]',
#      'Geometric Mean Ratio [90% CI]'
#    ),
#    abbreviations = list(
#      ABC = 'Some custom variable',
#      XYZ = 'Another custom variable'
#    )
#  )
#  
#  # Request Word table
#  make_gmr_table(
#    data = gmr_table_data,
#    file = 'gmtable.docx',
#    format = 'word',
#    title = 'Mouh',
#    headers = c(
#      'Exposure Measure',
#      'Covariate',
#      'Group',
#      'n',
#      'Geometric Mean [90% CI]',
#      'Geometric Mean Ratio [90% CI]'
#    ),
#    abbreviations = list(
#      ABC = 'Some custom variable',
#      XYZ = 'Another custom variable'
#    )
#  )
#  
#  # Request both with one call
#  make_gmr_table(
#    data = gmr_table_data,
#    file = c('gmtable.html, gmtable.docx'),
#    format = c('html', 'word'),
#    title = 'Mouh',
#    headers = c(
#      'Exposure Measure',
#      'Covariate',
#      'Group',
#      'n',
#      'Geometric Mean [90% CI]',
#      'Geometric Mean Ratio [90% CI]'
#    ),
#    abbreviations = list(
#      ABC = 'Some custom variable',
#      XYZ = 'Another custom variable'
#    )
#  )
#  

