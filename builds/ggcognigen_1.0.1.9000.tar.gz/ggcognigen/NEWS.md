# ggcognigen 1.1.0

* Include new functions supporting the creation of forest plots and associated tables: `make_gmr_data`, `make_gmr_table`, and `make_forestplot`

# ggcognigen 1.0.1

* In `geom_boxcount`, fixed count placements when no outliers are shown.

# ggcognigen 1.0.0

* Added a `NEWS.md` file to track changes to the package.
