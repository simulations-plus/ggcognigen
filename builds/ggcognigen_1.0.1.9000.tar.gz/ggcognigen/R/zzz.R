# Copyright 2020-2022-07-13 Cognigen Corporation, a Simulations Plus Company

#' @importFrom utils packageVersion
.onLoad <- function(libname, pkgname) {

  packageStartupMessage(
    sprintf(
      'Loading ggcognigen Version %s',
      packageVersion('ggcognigen')
    )
  )

  # Apply default Cognigen styling and theme for ggplot2
  set_default_style()

  # Apply default Cognigen theme
  ggplot2::theme_set(theme_cognigen())

  packageStartupMessage(
    '\nDefault style set to `cognigen_style()`\n',
    'Default theme set to `theme_cognigen()`'
  )

}

