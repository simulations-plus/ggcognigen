## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- eval = FALSE------------------------------------------------------------
#  install.packages('ggcognigen_0.1.0.tar.gz', type = 'source')

## ----setup--------------------------------------------------------------------
library(ggcognigen)

## ---- fig.dim = c(6, 4)-------------------------------------------------------
library(ggplot2)
ggplot(data = diamonds) +
  aes(x = carat, y = price) + 
  geom_point() +
  facet_wrap(vars(clarity)) +
  theme_cognigen()

## ---- fig.dim = c(6, 4)-------------------------------------------------------
ggplot(data = diamonds) +
  aes(x = carat, y = price) + 
  geom_point() +
  facet_wrap(vars(clarity)) +
  theme_cognigen_grid()

## ---- echo = FALSE------------------------------------------------------------
xydata <- subset(xydata, REP == 1)

## ---- fig.dim = c(8, 3.5)-----------------------------------------------------
set_default_style()
ggpubr::ggarrange(
  ggplot(data = xydata) +
    aes(x = TIME, y = CONCENTRATION) + 
    geom_point() +
    theme_cognigen(),
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS) +
    geom_boxplot() +
    theme_cognigen(),
  nrow = 1,
  ncol = 2
)


## ---- fig.dim = c(8, 3.5)-----------------------------------------------------
ggpubr::ggarrange(
  ggplot(data = xydata) +
    aes(x = TIME, y = CONCENTRATION, colour = DOSE, fill = DOSE, shape = DOSE) +
    geom_point() +
    geom_line() +
    theme_cognigen() +
    scale_discrete_cognigen(),
  ggplot(data = bardata) +
    aes(x = STUDY, y = COUNT, fill = GROUP) +
    geom_bar(stat = 'identity', position = 'stack', alpha = 1) +
    theme_cognigen() +
    scale_discrete_cognigen(geom = 'bar'),
  nrow = 1,
  ncol = 2
)

## ---- fig.dim = c(8, 3.5)-----------------------------------------------------
ggpubr::ggarrange(
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS) +
    geom_boxplot2(coef = 1.5, outlier.position = 'identity') +
    ggtitle('coef = 1.5') +
    theme_cognigen(),
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS) +
    geom_boxplot2(coef = 90, outlier.position = 'identity') +
    ggtitle('coef = 90') +
    theme_cognigen(),
  nrow = 1,
  ncol = 2
)

## ---- fig.dim = c(8, 3.5)-----------------------------------------------------
ggpubr::ggarrange(
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS) +
    geom_boxplot2(outlier.position = NULL) +
    ggtitle('NULL') +
    theme_cognigen(),
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS) +
    geom_boxplot2(outlier.position = 'identity') +
    ggtitle('\'identity\'') +
    theme_cognigen(),
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS) +
    geom_boxplot2() +
    ggtitle('default or \'jitter\'') +
    theme_cognigen(),
  nrow = 1,
  ncol = 3
)

## ---- fig.dim = c(8, 7)-------------------------------------------------------
ggpubr::ggarrange(
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS, color = CATEGORICAL, shape = CATEGORICAL, fill = CATEGORICAL) +
    geom_boxplot(
      notch = TRUE,
      position = position_dodge(width = 0.9)
    ) +
    ggtitle('geom_boxplot()') +
    theme_cognigen() +
    scale_discrete_cognigen(),
  ggplot(data = boxdata) +
    aes(x = GROUP, y = CONTINUOUS, color = CATEGORICAL, shape = CATEGORICAL, fill = CATEGORICAL) +
    geom_boxplot2(
      notch = TRUE,
      position = position_dodge(width = 0.9)
    ) +
    ggtitle('geom_boxplot2()') +
    theme_cognigen() +
    scale_discrete_cognigen(),
  nrow = 2,
  ncol = 1

)

## ---- fig.dim = c(8, 3.5)-----------------------------------------------------
ggplot(data = boxdata) +
  aes(x = GROUP, y = CONTINUOUS, color = CATEGORICAL, shape = CATEGORICAL, fill = CATEGORICAL) +
  geom_boxplot2(
    notch = TRUE,
    position = position_dodge(width = 0.9)
  ) +
  geom_boxcount(
    position = position_dodge(width = 0.9)
  ) + 
  theme_cognigen() +
  scale_discrete_cognigen()

## ---- fig.dim = c(6, 4)-------------------------------------------------------
ggplot(mpg, aes(class, hwy)) +
  geom_boxplot2() +
  geom_boxcount() +
  scale_y_continuous(trans = 'log10')  + 
  theme_cognigen()

