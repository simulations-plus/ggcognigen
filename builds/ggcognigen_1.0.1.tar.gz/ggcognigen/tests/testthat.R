library(testthat)
library(ggcognigen)

test_check("ggcognigen")
